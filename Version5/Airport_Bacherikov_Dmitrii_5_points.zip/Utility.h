#ifndef _UTILITY_H
#define _UTILITY_H
enum Error_code { success, overflow, underflow, fail };

#endif

